import pandas as pd
import pygslib as p
# import matplotlib.pylab as plt
import matplotlib.pyplot as plt
import numpy as np
from histograms import plot_histogram


class Estimate:

    def __init__(self, data):
        self.data = data
        

    def load_data(self):
        """Import data from csv files"""
        self.collar = pd.read_csv(self.data['collar'])
        self.survey = pd.read_csv(self.data['survey'])
        self.assay = pd.read_csv(self.data['assay'])
        self.geology = pd.read_csv(self.data['geology'])
        # print(self.assay.head(60))

    def create_database(self):
        """create a drillhole object(database)"""
        self.dhole_db= p.drillhole.Drillhole(collar=self.collar, survey=self.survey)

    def add_interval_tables(self):
        """now you can add as many interval tables as you want, for example, assays, lithology and RQD."""
        self.dhole_db.addtable(self.assay, 'assay', overwrite = False)
        self.dhole_db.addtable(self.geology, 'geology', overwrite = False)


    def validate_dhole_db(self):
        """validating a drillhole object and """
        self.dhole_db.validate()

    
    def validate_intervals_tables(self):
        """validating interval tables"""
        self.dhole_db.validate_table('geology')
        self.dhole_db.validate_table('assay')


    def composite(self):
        """Compositing"""
        ##Calculating length of sample intervals
        self.dhole_db.table['assay']['Length'] = self.dhole_db.table['assay']['TO']- self.dhole_db.table['assay']['FROM']
        # print(self.dhole_db.table['assay'].head(10))

        length_mode = self.dhole_db.table['assay']['Length'].mode()[0]  #Find the length mode
        # print ('The Length Mode is:',length_mode)

        # plotting the interval lengths
        # plot_histogram(data =self.dhole_db.table['assay']['Length'], bin_edges=[0,2,4,6,8,10,12,14])

        ## Compositing
        self.dhole_db.downh_composite(
            'assay',
            variable_name= "caco3",
            new_table_name= "CMP",
            cint = length_mode,
            minlen=-1,
            overwrite = True
        )
      
        self.dhole_db.desurvey('CMP',warns=False, endpoints=True) # Desurveying and create a table with desurveyed points
    
        self.dhole_db.txt2intID('CMP') # creating BHID of type integer of the desurveyed table
        # print (mydholedb.table["CMP"][['BHID', 'BHIDint', 'FROM', 'TO']].head(70))

        #exporting results to VTK
        self.dhole_db.intervals2vtk('CMP', 'kabini.vtk')

        self.dhole_db.table["CMP"].to_csv('KabiniCMPdb.csv', index=False)


    def inspect_interval_tables(self):
        print ("Table names ", self.dhole_db.table_mames)
    
    
    
    def run(self):
        self.load_data()
        self.create_database()
        self.add_interval_tables()
        # self.validate_intervals_tables()
        # self.validate_dhole_db()
        self.composite()
        self.inspect_interval_tables()
    
    
if __name__ == '__main__':
    data = {
        'collar': 'COLLAR CSV.csv',
        'survey': 'SURVEY CSV.csv',
        'assay': 'ASSAY CSV.csv',
        'geology': 'GEOLOGY.csv',
    }
    bot = Estimate(data)
    bot.run()